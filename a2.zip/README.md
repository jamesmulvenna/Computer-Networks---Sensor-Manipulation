Principles of Computer Networks 
COMP 3203 - Fall 2016
# Coverage of a Unit Interval with Sensors
Authors:
   - Christopher McMorran - 100968013 [chrismcmorran](https://github.com/chrismcmorran)
   - James Mulvenna       - 100965629 [jamesmulvenna](https://github.com/jamesmulvenna)
   - Jenish Zalavadiya    - 100910343 [jenishzalavadiya](https://github.com/jenishzalavadiya)
